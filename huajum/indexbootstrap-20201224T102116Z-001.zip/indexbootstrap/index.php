<!DOCTYPE html>
<html lang="en">
<head>
    <title>Homepage</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
<style>
    body{ margin: 0; padding: 0;background: url(bg5.jpg) no-repeat; background-size: cover;}
    
    .btn-dark{background-color:rgba(0, 0, 0, 0.377);color:white; }
            
</style>  
    <nav class="navbar navbar-expand-md bg-dark navbar-dark">
        <a class="navbar-brand" href="#">
            <img src="huajum2.png" alt="Logo" style="width:40px;"> HUAJUM
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="#">Phetcharat</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Sutatip</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Chonticha</a>
            </li>    
        </ul>
    </div>  
    </nav>


        <div class="container-fluid" >
        <center>
        <!-- <center><img src="huajum2.png" width="490" height="400"> -->
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
         <b> <p style= "font-size: 50px; color: azure;"> WEB <span style="color:rgb(130, 166, 231);">TECHNOLOGY</span></p></b>
            <a href="#" type="button" class="btn btn-dark">Contact Us</a>
            
         
            <audio autoplay id="bgsound">
             <source src="สวัสดีปีใหม่.mp3"
             type="audio/mp4">
            </audio> 
         
        </center>

    </div>
    

</body>
</html> 